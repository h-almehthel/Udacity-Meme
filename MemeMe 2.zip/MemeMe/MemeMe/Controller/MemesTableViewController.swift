//
//  MemesTableViewController.swift
//  MemeMe
//
//  Created by AlHassan Al-Mehthel on 06/09/1441 AH.
//  Copyright © 1441 AlHassan Al-Mehthel. All rights reserved.
//

import UIKit

class MemesTableViewController: UITableViewController {

    // cell identifier
    let cellid = "cellid"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // register tableView cell identifier with nib file
        tableView.register(UINib(nibName: "MemeTableViewCell", bundle: nil), forCellReuseIdentifier: cellid)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        // reload tableView data to show new memes
        tableView.reloadData()
        
        // show tabbar
        tabBarController?.tabBar.isHidden = false
    }
    
    

    
    @IBAction func editAction(_ sender: Any) {
        
    }
    
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AppDelegate.share.memes.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellid, for: indexPath) as! MemeTableViewCell

        let meme = AppDelegate.share.memes[indexPath.row]
        cell.memeText.text = meme.topText + "..." + meme.bottomText
        cell.memeImage.image = meme.memedImage

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let memeDetailsVC = MemeDetailsViewController()
        
        // send meme object to MemeDetailsViewController
        memeDetailsVC.meme = AppDelegate.share.memes[indexPath.row]
        
        // navigate to MemeDetailsViewController
        navigationController?.pushViewController(memeDetailsVC, animated: true)
    }

}
