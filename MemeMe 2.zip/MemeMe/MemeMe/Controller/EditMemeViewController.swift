//
//  EditMemeViewController.swift
//  MemeMe
//
//  Created by AlHassan Al-Mehthel on 04/09/1441 AH.
//  Copyright © 1441 AlHassan Al-Mehthel. All rights reserved.
//

import UIKit

class EditMemeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var topTextField: UITextField!
    
    @IBOutlet weak var bottomTextField: UITextField!
    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // textFields style
        prepareTextField(string: "TOP", textField: topTextField)
        prepareTextField(string: "BOTTOM", textField: bottomTextField)
        
        shareButton.isEnabled = false
        
        // keyboard controll
        settingUpKeyboardNotifications()
    }
    
    // prepare textFields attributes (font - colors - size)
    func prepareTextField(string: String, textField: UITextField) {
        let memeTextAttributes: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key.strokeColor: UIColor.black,
            NSAttributedString.Key.foregroundColor: UIColor.white,
            NSAttributedString.Key.font: UIFont(name: "impact", size: 40)!,
            NSAttributedString.Key.strokeWidth: -3
        ]
        
        
        let attributedString = NSAttributedString(string: string, attributes: memeTextAttributes)
        textField.attributedText = attributedString
        textField.defaultTextAttributes = memeTextAttributes

        textField.textAlignment = .center
        textField.delegate = self
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        // disable camera button if device hasn't camera
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
    }

    // dismiss keyboard when touching super view
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    @IBAction func cancelAction(_ sender: UIBarButtonItem) {

    }
    
    // share memed image and save it
    @IBAction func shareAction(_ sender: UIBarButtonItem) {
        let memedImage = generateMemedImage()
        
        let ac = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        
        ac.completionWithItemsHandler =  { (activityType, completed, returnedItems, activityError) -> Void in
            if completed {
              //Call the save() method
                self.save(memedImage: memedImage)
                self.dismiss(animated: true, completion: nil)
            }
        }
        
        present(ac, animated: true)
    }
    
    // save meme object
    func save(memedImage : UIImage) {
        let memeObject = Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: myImageView.image!, memedImage: memedImage)
        
        AppDelegate.share.memes.append(memeObject)
        
    }
    
    
    
    func generateMemedImage() -> UIImage {

        // TODO: Hide toolbar and navbar
        navigationController?.navigationBar.isHidden = true
        toolBar.alpha = 0

        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()

        // TODO: Show toolbar and navbar
        navigationController?.navigationBar.isHidden = false
        toolBar.alpha = 1
        return memedImage
    }
    
    
    @IBAction func albumAction(_ sender: Any) {
        pickImage(sourceType: .photoLibrary)
    }
    

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage

        myImageView.image = image
        
        shareButton.isEnabled = true
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cameraAction(_ sender: Any) {
        pickImage(sourceType: .camera)
    }
    
    // pick image from photo library or camera
    func pickImage(sourceType: UIImagePickerController.SourceType){
         let imagePicker = UIImagePickerController()
         imagePicker.delegate = self
         imagePicker.sourceType = sourceType
         present(imagePicker, animated: true, completion: nil)
    }
    
}


extension EditMemeViewController : UITextFieldDelegate {
    
    // removing default text when start editing
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.tag == 10 {
            if textField.text == "TOP" {
                textField.text = ""
            }
        }
            
        else {
            if textField.text == "BOTTOM" {
                textField.text = ""
            }
        }
    }
    
    // write default text when end editing with empty text
    func textFieldDidEndEditing(_ textField: UITextField) {
        let trimmed = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) // trim whitespaces
        textField.text = trimmed
        
        if textField.tag == 10 {
            if textField.text == "" {
                textField.text = "TOP"
            }
        } else {
            if textField.text == "" {
                textField.text = "BOTTOM"
            }
        }
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // return key to dismiss keyboard
        return true
    }

    
    
}


// Keyboard controll
extension EditMemeViewController {
    
    func settingUpKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(EditMemeViewController.keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(EditMemeViewController.keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    // show keyboard when start textField editing
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            // move the view up when start editing bottom textField
            if bottomTextField.isFirstResponder {
                self.view.frame.origin.y = -(keyboardSize.height)
            }
            UIView.animate(withDuration: 0.3, delay: 0, options: [], animations: {
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    // dismiss keyboard
    @objc func keyboardWillHide(notification: NSNotification) {
        // return the view back to y = 0
        self.view.frame.origin.y = 0
        UIView.animate(withDuration: 0.3, delay: 0, options: [], animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    
}
