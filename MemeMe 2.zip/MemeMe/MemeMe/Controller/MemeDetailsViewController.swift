//
//  MemeDetailsViewController.swift
//  MemeMe
//
//  Created by AlHassan Al-Mehthel on 06/09/1441 AH.
//  Copyright © 1441 AlHassan Al-Mehthel. All rights reserved.
//

import UIKit

class MemeDetailsViewController: UIViewController {

    // meme object
    var meme : Meme?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = "Meme Details"
        
        // hide TabBarViewController
        tabBarController?.tabBar.isHidden = true
        
        // add memeImageView to super view
        view.addSubview(memeImageView)
        
        // assign memedImage to memeImageView
        memeImageView.image = meme?.memedImage
    }
    

    // create memeImageView programmatically
    lazy var memeImageView : UIImageView = {
        $0.frame = self.view.bounds
        $0.contentMode = .scaleAspectFit
        return $0
    }(UIImageView())
    

}
