//
//  MemeTableViewCell.swift
//  MemeMe
//
//  Created by AlHassan Al-Mehthel on 06/09/1441 AH.
//  Copyright © 1441 AlHassan Al-Mehthel. All rights reserved.
//

import UIKit

class MemeTableViewCell: UITableViewCell {

    @IBOutlet weak var memeText : UILabel!
    @IBOutlet weak var memeImage : UIImageView!

}
