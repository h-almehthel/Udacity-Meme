//
//  MemeObject.swift
//  MemeMe
//
//  Created by AlHassan Al-Mehthel on 05/09/1441 AH.
//  Copyright © 1441 AlHassan Al-Mehthel. All rights reserved.
//

import UIKit

struct Meme {
    let topText: String
    let bottomText: String
    let originalImage : UIImage
    let memedImage : UIImage
}
